<?php 

interface CRUD{
	
	function Read();
	function ReadAll();
	// function Create();
	function ReadInSelect();
	// function Update($id);
	function Delete($id);
}
 ?>
